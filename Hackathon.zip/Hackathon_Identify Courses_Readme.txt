Topic:- Identify Courses


# Problem Statement
The goal of this project is to identify and display web development courses that meet the following criteria:
 
1. The course should be at a beginner's level.
2. The course should be offered in English.
3. Display the first two courses with their names, total learning hours, and ratings.


Suggested site:- coursera.org

# Detailed Description: Hackath Ideas
The project involves the following tasks:
1. Search for Web Development Courses: Search for web development courses that are designed for beginners and offered in English. Extract the names, total learning hours, and ratings for the first two courses.
2. Look for Language Learning: Extract all the languages and different levels with their total count and display them.
3. Form Filling and Error Capture: On the home page, navigate to "For Enterprise" and look into Courses for Campus under Product. Fill the "Ready to transform" form with at least one invalid input (for example, email), capture the error message, and display it.


# Key Automation Scope
1. Handling different browser windows, search option
2. Extracting multiple dropdown list items and storing them in collections
3. Navigating back to the home page
4. Filling forms (in different objects on the webpage)
5. Capturing warning messages
6. Scrolling down on the webpage.
 
# Dependencies
1. Selenium <4.15.0>
2. TestNG <7.7.1>
3. Extend Report <⁠5.0.9>